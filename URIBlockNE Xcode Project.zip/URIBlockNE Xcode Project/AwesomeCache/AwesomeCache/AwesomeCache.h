//
//  AwesomeCache.h
//  AwesomeCache
//
//  Created by Alexander Schuch on 31/01/15.
//  Copyright (c) 2015 Alexander Schuch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AwesomeCache.
FOUNDATION_EXPORT double AwesomeCacheVersionNumber;

//! Project version string for AwesomeCache.
FOUNDATION_EXPORT const unsigned char AwesomeCacheVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AwesomeCache/PublicHeader.h>


#import <AwesomeCache/NSKeyedUnarchiverWrapper.h>