//
//  NSKeyedUnarchiverWrapper.h
//  Example
//
//  Created by Javier Soto on 5/17/16.
//  Copyright © 2016 Alexander Schuch. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSObject * __nullable _awesomeCache_unarchiveObjectSafely(NSString * __nonnull path);
